const BASE_URL = "http://localhost:4000/api";
export default BASE_URL;

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL;
export { SOCKET_URL };